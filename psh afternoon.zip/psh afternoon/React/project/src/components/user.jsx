import React from "react";
import { useParams } from "react-router-dom";
import peoples from "../../data";

function User() {
  const unique = useParams();

  const specificuser = peoples.find((user) => user.id === +unique.id);

  if (!specificuser) {
    return <h1 className="text-white">No Data found against given id</h1>;
  }

  return (
    <div className="text-white">
      <img src={specificuser.picture} alt="" />
      <h1> Name: {specificuser.name} </h1>
      <h1>Age : {specificuser.age}</h1>
    </div>
  );
}

export default User;
