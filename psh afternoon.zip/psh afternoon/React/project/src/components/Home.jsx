import peoples from "../../data.js";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div
      className=" flex justify-center items-center  gap-5 flex-wrap w-full p-8
    "
    >
      {peoples.map((user) => (
        <Link
          to={`/user/${user.id}`}
          className="bg-cyan-300 h-96 w-1/5  rounded-3xl "
        >
          <div>
            <img
              src={user.picture}
              alt={user.name}
              className="rounded-t-3xl w-full"
            />
            <div className="p-3 font-bold ">
              <h2>
                Name : <span className="text-orange-500">{user.name}</span>
              </h2>
              <h2>
                Age : <span className="text-orange-500">{user.age}</span>
              </h2>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default Home;
