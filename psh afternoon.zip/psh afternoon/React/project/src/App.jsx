import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import User from "./components/user";

function App() {
  return (
    <div className="bg-slate-900 h-full w-screen ">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/user/:id" element={<User />} />
          <Route path="*" element={<h1>Page not found</h1>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
