import React from "react";
import Hero from "./components/Home/Hero";
import Feature from "./components/Home/Featured";
import Brand from "./components/Home/Brand";
import CTA from "./components/Home/CTA";
import Footer from "./components/layout/Footer";
import AboutMain from "./components/About/Main";
import Team from "./components/About/Team";
import Contact from "./components/contact/Contact";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/layout/Navbar";
import NotFound from "./components/layout/NotFound";
import Person from "./components/person/person";

function App() {
  const pathname = window.location.pathname;

  return (
    <>
      <BrowserRouter>
        {(pathname === "/" ||
          pathname === "/contact" ||
          pathname === "/about") && <Navbar />}

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />

          <Route path="/user/:id" element={<Person />} />

          <Route path="*" element={<NotFound />} />
        </Routes>

        {(pathname === "/" ||
          pathname === "/about" ||
          pathname === "/contact") && <Footer />}
      </BrowserRouter>
    </>
  );
}

export default App;

function Home() {
  return (
    <>
      <Hero />
      <Feature />
      <Brand />
      <CTA />
    </>
  );
}

function About() {
  return (
    <>
      <AboutMain />
      <Team />
    </>
  );
}
