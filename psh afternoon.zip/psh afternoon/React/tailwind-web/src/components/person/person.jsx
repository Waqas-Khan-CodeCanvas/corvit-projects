import React from "react";
import { useParams } from "react-router-dom";

function Person() {
  const uniquePart = useParams();
  console.log(uniquePart);
  return (
    <div>
      <h1>Welcome to this dynamic page Mr/Mrs {uniquePart.id} </h1>
    </div>
  );
}

export default Person;
