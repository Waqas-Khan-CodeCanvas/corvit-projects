// // import Profile from "./components/Profile.jsx";
// // import "./App.css";

// import Profile from "./components/Profile";

// // function App() {
// //   const myCarInfo = {
// //     name: "honda",
// //     mode: 2022,
// //     color: "black",
// //   };

// //   const myHobbies = ["reading book", "cooking"];
// //   const myName = "Ali";
// //   const myAge = 22;
// //   const myGender = "male";
// //   return (
// //     <>
// //       {/* prop  */}
// //       <Profile
// //         name={myName}
// //         age={myAge}
// //         gender={myGender}
// //         hobby={myHobbies}
// //         carInfo={myCarInfo}
// //       />
// //       <Profile />
// //       {/* <Profile /> */}
// //       {/* <Profile name="Ahmad" age={18} alive={true} address={[]} gender="male" />
// //       <Profile name="Ramish" age="22" gender="male" /> */}
// //     </>
// //   );
// // }
// // export default App;
// // import Profile from "./components/Profile.jsx";

// // const usersData = [
// //   { name: "Ali", age: 23, gender: "male" }, //0
// //   { name: "Ahmad", age: 17, gender: "male" }, //1
// //   { name: "Ayesha", age: 39, gender: "female" }, //2
// // ];

// // function App() {
// //   return (
// //     <>
// //       {usersData.map((user) => (
// //         <Profile data={user} />
// //       ))}
// //     </>
// //   );
// // }

// // export default App;

// // async function FetchData() {
// //   try {
// //     const response = await fetch("https://randomuser.me/api?results=50");
// //     const data = await response.json();
// //     const usersData = data.results;
// //     return usersData;
// //   } catch (err) {
// //     return err;
// //   }
// // }
// // const users = await FetchData();

// // function App() {
// //   return (
// //     <div
// //       style={{
// //         display: "flex",
// //         justifyContent: "center",
// //         alignItems: "center",
// //         flexWrap: "wrap",
// //         gap: "20px",
// //         backgroundColor: "#e28743",
// //         padding: "20px",
// //       }}
// //     >
// //       {users.map((item) => (
// //         <Profile user={item} />
// //       ))}
// //     </div>
// //   );
// // }

// // export default App;

// // import React from "react";

// // function App() {
// //   // function HandleClick() {
// //   //   console.log("you clicked me");
// //   // }

// //   // function HandleSubmit(evt) {
// //   //   evt.preventDefault();
// //   //   const name = evt.target.username.value;
// //   //   const password = evt.target.pass.value;
// //   //   console.log(name, password);
// //   //   evt.target.reset();
// //   // }
// //   return (
// //     <div>
// //       {/* <button
// //         onClick={HandleClick}
// //         onMouseOver={() => console.log("mouse enter")}
// //         onMouseOut={() => console.log("mouse out")}
// //       >
// //         Click Me
// //       </button>

// //       <input type="text" onChange={(evt) => console.log(evt.target.value)} /> */}
// //       {/* <form onSubmit={(evt) => HandleSubmit(evt)}>
// //         <label htmlFor="username">Username</label>
// //         <input type="text" name="username" id="username" />
// //         <br />
// //         <br />
// //         <label htmlFor="password">Password</label>
// //         <input type="password" name="pass" id="password" />
// //         <br />
// //         <button>Login</button>
// //       </form> */}
// //     </div>
// //   );
// // }

// // export default App;

// // import React from "react";
// // import Todo from "./components/Todo";
// // import "./App.css";
// // const todos = [
// //   {
// //     todo: "Wash Dishes",
// //     status: true,
// //   },
// //   {
// //     todo: "wash clothes",
// //     status: true,
// //   },
// //   {
// //     todo: "Homework",
// //     status: false,
// //   },
// //   {
// //     todo: "Dinner",
// //     status: false,
// //   },
// //   {
// //     todo: "Clean Room",
// //     status: true,
// //   },
// //   {
// //     todo: "Grocery",
// //     status: true,
// //   },
// // ];

// // function App() {
// //   return (
// //     <div>
// //       {todos.map((todo) => (
// //         <Todo item={todo} />
// //       ))}
// //     </div>
// //   );
// // }

// // export default App;

// import React, { createContext } from "react";
// import Navbar from "./components/Navbar";
// import Sidebar from "./components/sidebar";
// import Counter from "./components/Counter";
// import Todolist from "./components/Todolist";
// import Home from "./components/Home";
// import "./App.css";

// // let count = 1;
// // setInterval(() => {
// //   console.log(count);
// // }, 2000);
// const name = "Mughees";
// export const Data = createContext();
// function App() {
//   // const count =  1
//   // getter setter

//   console.log(" rendered App");

//   return (
//     <div>
//       <Data.Provider value={{ name: "john", age: "32", gender: "male" }}>
//         <Home />
//       </Data.Provider>
//       <h1 cnm></h1>
//       <Sidebar />
//     </div>
//   );
// }

// export default App;

import React, { useState } from "react";

function App() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <header
      className=" text-white flex justify-between items-center p-7   bg-gradient-to-r from-indigo-600 via-orange-400 to-fuchsia-500 
 "
    >
      <h1 className="font-bold text-3xl md:font-extrabold md:text-5xl  ">
        Tailwind
      </h1>

      <nav className="hidden list-none gap-6 font-bold text-lg md:flex  ">
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
        <li>Princing</li>
        <li>Services</li>
      </nav>
      {isOpen && (
        <nav className="block md:hidden  list-none gap-6 font-bold text-lg  ">
          <li>Home</li>
          <li>About</li>
          <li>Contact</li>
          <li>Princing</li>
          <li>Services</li>
        </nav>
      )}

      <div>
        <button className=" font-bold text-2xl underline ">Login </button>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className=" inline md:hidden mx-4 text-3xl"
        >
          {isOpen ? "X" : "="}
        </button>
      </div>
    </header>
    // <div className="bg-gradient-to-b from-red-600  via-orange-400 to-indigo-700 h-1/2 rounded-tl-[220px] rounded-br-[350px] w-1/2">
    //   <h1>Hi how are</h1>
    // </div>
  );
}

export default App;

//  0px => 625px
//  625px => 768px sm
//  768px => 1020px md
//  1020px => 1280px lg
//  1280 => onwards xl
