import { useContext } from "react";
import { Data } from "../App";
function Sidebar() {
  const info = useContext(Data);
  console.log("Rendered Sidebar", info);

  return <div>Sidebar </div>;
}

export default Sidebar;
