import React from "react";

function Todo({ item }) {
  return (
    <div>
      {/* first approch */}
      {item.status ? (
        <h1 style={{ color: "green" }}> User Completed {item.todo} </h1>
      ) : (
        <h1 style={{ color: "red" }}> User doesn't completed {item.todo} </h1>
      )}
      {/* second approch */}

      <h1 style={item.status ? { color: "green" } : { color: "red" }}>
        {item.status
          ? `User Completed ${item.todo}`
          : `User doesn't ${item.todo}`}
      </h1>
      {/* third approch */}
      <h1 className={`${item.status && "completed"}`}>
        {item.status
          ? `User Completed ${item.todo}`
          : `User doesn't ${item.todo}`}
      </h1>

      {/* {
            if(item.status){

                <h1> User Completed {item.todo} </h1>
            }else{

                
                <h1> User doesn't completed {item.todo} </h1>
            }
        } */}
    </div>
  );
}

export default Todo;

// ternary operater
