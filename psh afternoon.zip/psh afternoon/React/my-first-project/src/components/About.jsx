import React from "react";
import Contact from "./Contact";
import { useContext } from "react";
import { Data } from "../App";

function About() {
  const info = useContext(Data);
  console.log("from About", info);
  return (
    <div>
      About me i am
      <Contact />
    </div>
  );
}

export default About;
