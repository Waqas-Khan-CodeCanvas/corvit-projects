// // function Profile({
// //   name = "user",
// //   age = "not found",
// //   gender = "rather not cnfrm",
// //   hobby = "not found",
// //   carInfo = "not found",
// // }) {
// //   return (
// //     <div>
// //       <h1>My name is {name} </h1>
// //       <h1>I am {age} years old </h1>
// //       <h1>My gender is {gender} </h1>
// //       <h1>My hobbies are {hobby}</h1>
// //       <h1>My car is {carInfo.name} </h1>
// //     </div>
// //   );
// // }

// // export default Profile;
// // const myInfo = {
// //   name: "john",
// //   age: 22,
// // };
// // console.log(myInfo.name);
// // console.log(myInfo.age);

// // const { name, age } = myInfo;
// // console.log("des", name);

// export default function Profile({ data }) {
//   console.log(data);
//   return (
//     <div
//       style={{
//         backgroundColor: "purple",
//         color: "white",
//         width: "400px",
//         margin: "20px",
//         borderRadius: "10px",
//         padding: "10px",
//       }}
//     >
//       <h1>
//         My name is <span style={{ color: "orange" }}>{data.name}</span>
//       </h1>
//       <h1>
//         I am <span style={{ color: "orange" }}> {data.age}</span> years old
//       </h1>
//       <h1>
//         I am a <span style={{ color: "orange" }}>{data.gender}</span>
//       </h1>
//     </div>
//   );
// }

import React from "react";

function Profile({ user }) {
  console.log(user);
  return (
    <div
      style={{
        backgroundColor: "#1888b6",
        color: "white",
        borderRadius: "20px",
        padding: "20px",
        width: "400px",
      }}
    >
      <img
        src={user.picture.large}
        alt=""
        style={{ borderRadius: "100%", height: "200px", width: "200px" }}
      />
      <h2>Name: {`${user.name.title} ${user.name.first} ${user.name.last}`}</h2>
      <h2>Age: {user.dob.age} Years old</h2>
      <h2>Gender: {user.gender}</h2>
      <h2>Email: {user.email}</h2>
    </div>
  );
}

export default Profile;
