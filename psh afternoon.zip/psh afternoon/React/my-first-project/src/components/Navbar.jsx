export default function Navbar() {
  console.log("rendered Navbar");
  return (
    <nav>
      <h1>Navbar</h1>
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
        <li>Pricing</li>
      </ul>
    </nav>
  );
}

// export default Navbar;
