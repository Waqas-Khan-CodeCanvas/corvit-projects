import { useContext } from "react";
import { Data } from "../App.jsx";

function Contact() {
  const context = useContext(Data);
  console.log("from contact", context);
  return (
    <div>
      Contact me my name is {context.name} i'm {context.age} years old and i am
      a {context.gender}
    </div>
  );
}

export default Contact;
