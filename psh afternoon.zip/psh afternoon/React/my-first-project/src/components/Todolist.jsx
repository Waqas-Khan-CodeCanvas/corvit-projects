import React, { useEffect, useState } from "react";

function Todolist() {
  const [Todos, setTodos] = useState([]);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const getTodos = localStorage.getItem("todos");
    if (getTodos) {
      const data = JSON.parse(getTodos);
      setTodos(data);
    }
  }, []);

  function HandleSubmit(event) {
    event.preventDefault();
    const todo = event.target.todo.value;
    const newTodos = [...Todos, todo];
    setTodos(newTodos);
    localStorage.setItem("todos", JSON.stringify(Todos));
    event.target.reset();
  }

  function HandleDelete(idx) {
    Todos.splice(idx, 1);
    const updatedTodos = [...Todos];
    setTodos(updatedTodos);
  }

  return (
    <div>
      <form onSubmit={(e) => HandleSubmit(e)}>
        <input type="text" name="todo" required />
        <button>Add Todo</button>
      </form>
      {Todos.map((item, idx) => (
        <div key={idx} style={{ display: "flex", gap: "20px", margin: "10px" }}>
          <li>{item}</li>
          <button onClick={() => HandleDelete(idx)}>Delete</button>
        </div>
      ))}
      <div>
        <button onClick={() => setCount(count - 1)}>-</button>
        <span>{count}</span>
        <button onClick={() => setCount(count + 1)}>+</button>
      </div>
    </div>
  );
}

export default Todolist;
