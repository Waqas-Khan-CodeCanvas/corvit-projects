import React from "react";
import About from "./About";

function Home() {
  return (
    <div>
      Home
      <About />
    </div>
  );
}

export default Home;
