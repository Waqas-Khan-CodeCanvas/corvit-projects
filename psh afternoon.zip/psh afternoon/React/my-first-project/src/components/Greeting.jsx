import "./Greeting.css";
function Greeting() {
  return (
    <div>
      <h1>Default Greeting Component</h1>
    </div>
  );
}

function Greeting2() {
  return <div>Greeting2</div>;
}

function Greeting3() {
  return <div>Greeting3</div>;
}

export default Greeting; //default export
export { Greeting2, Greeting3 }; //named export
