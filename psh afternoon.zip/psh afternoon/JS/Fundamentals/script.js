// // alert("Hello World From John");
// // alert("Heyy");

// // Print Statment
// // console.log(10 + 10);

// // syntax
// // console.log("sfsfsffs");
// // console.log(1000000);
// // console.log("Welcome!");

// // Variables
// //  company = age = marks = "Corvit";
// // company = "Corvit";

// // console.log("I am a web developer at", company);
// // console.log("I am a web developer at", company);
// // console.log("I am a web developer at", company);

// // let age = 21; //changeable
// // const name = "John"; //unchangeable

// // console.log(name, "is", age, "years old"); //2021
// // age = 22;
// // console.log(name, "is", age, "years old"); //2022
// // // name = "Ahmad";
// // console.log(name, "is", age, "years old");

// // Naming Variables
// // case sensitive
// // let full_name = "John Doe";

// // _ $
// // let num1 = 10;
// // let num2 = 20;

// // let num1 =
// // Camel Case
// // let fatherName = "Doe";
// // H1 h1
// // let const = ""
// // let for  = ""

// // let num1 =

// // Data Types
// // let myName = "John"; //string
// // let age = 12; //Number
// // let price = 20.9; //Number
// // let alive = true; // Boolean
// // let strength; //undefined
// // console.log(strength);
// let nothing = null; // null/empty
// // console.log(nothing);

// // Arthemtic Operations
// // let num1 = 10;
// // const num2 = 2;

// // const addition = num1 + num2;
// // console.log("The result of addition is", addition);

// // const subtraction = num1 - num2;
// // console.log(subtraction);

// // const multiplication = num1 * num2;
// // console.log(multiplication);

// // const division = num1 / num2;
// // console.log(division);

// // // modulus
// // const mod = num1 % num2; //remainder
// // console.log(mod);

// // // exponent
// // const exp = num1 ** num2; //powers
// // console.log(exp);

// // For Addition
// // const num1 = "22";
// // const num2 = 22;
// // const result = num1 + num2; //string concatenation
// // console.log(typeof result);

// // For Other Operations
// // const num1 = "22";
// // const num2 = 22;
// // const result = num1 - num2;
// // console.log(typeof result);

// // typescript

// // let age = 31;
// // console.log(typeof age);

// // age = "";
// // console.log(typeof age);
// // let age = "num";

// // Comparison Operaters
// //  >
// //  <
// //  == euqlity
// //  = assignment
// //  !=
// // >=
// // <=
// // ===

// // const userAge = "18";

// // const greater = userAge > 18; //checking for greater
// // // console.log("Greater " + greater);

// // const smaller = userAge < 18;
// // // console.log("Smaller " + smaller);

// // const equality = userAge == 18;
// // // console.log("Equality " + equality);

// // const notEqual = userAge != 18;
// // // console.log("Not Equal " + notEqual);

// // const greaterEqual = userAge >= 18;
// // // console.log("Greater & Equal " + greaterEqual);

// // const smallerEqual = userAge <= 18;
// // // console.log("Smaller & Equal " + smallerEqual);

// // const trippleEqual = userAge === 18;
// // // console.log(trippleEqual);

// // const boolCheck = true == 1;
// // // console.log(boolCheck);

// // String Methods
// // const firstName = "John ";
// // const lastName = "Doe";

// // const fullName = firstName + lastName;
// // console.log(fullName);

// // Concat
// // const fullName = firstName.concat(lastName);
// // console.log(fullName);

// // db {
// //     username = ""
// // }
// // const userName = prompt("enter your name");
// // // console.log(userName);
// // // Length
// // const length = userName.length;
// // // console.log(length);

// // // const upperCase = userName.toUpperCase();
// // // // console.log(upperCase);

// // // const lowerCase = userName.toLowerCase();
// // // console.log(lowerCase);

// // const username = "Anodrio";
// // // console.log(username.indexOf("o"));

// // const character = userName.charAt(0).toUpperCase();
// // console.log(character);

// // const bio = "Mughees is mern stack developer";
// // console.log(bio.indexOf("a"));
// // const include = bio.includes("mern stack developer");
// // // console.log(include);

// // const slice = bio.slice(1, 5);
// // console.log(slice);

// // const myName = "mugheesmmm";
// // const replace = myName.replace("m", "M");
// // console.log(replace);

// // const replaceAll = myName.replaceAll("m", "M");
// // console.log(replaceAll);

// // prompt = "muGhEeS";

// // Mughees;

// // Math Methods
// const randomNumber = Math.random() * 6;
// // console.log("Original Number", randomNumber);

// // round 9.5 =10  9.4 =9
// const roundOff = Math.round(randomNumber);
// // console.log("Round Off", roundOff);

// // ceil 9.1 =10 9.9 =10
// const bigger = Math.ceil(randomNumber);
// // console.log("Ceil", bigger);

// // floor 9.9 = 9 9.1 =9
// const smaller = Math.floor(randomNumber);
// // console.log("Floor", smaller);

// const fixed = randomNumber.toFixed(2);
// // console.log("To Fixed", fixed);

// // logical operaters
// // AND
// // age >= 18  AND  nationality === "pakistan"  = true
// // OR
// // age >= 18  OR nationality === "pakistan"  = true
// // NOT
// // false

// // const age = 17;
// // const nationality = "PakIsTan";

// // const AND = age >= 18 && nationality.toUpperCase() === "PAKISTAN";
// // // console.log(AND);

// // const OR = age >= 18 || nationality.toLowerCase() === "pakistan";
// // console.log(OR);

// // const NOT = false;
// // console.log(!NOT);

// // Conditional Statments
// // agr strength >= 15 console.log("we will take class")

// // if (condition) {
// //   // block of code to be executed
// // }
// // const age = 21;
// // if (age >= 18 && age < 60) {
// //   console.log("You can apply for visa");
// // } else {
// //   console.log("You can't apply for visa");
// // }

// // const percentage = 89;

// // if (percentage >= 90) {
// //   console.log("Grade A");
// //   // nesting
// //   if (percentage >= 95) {
// //     console.log("Reward = 100$");
// //   }
// // } else {
// //   console.log("better luck next time");
// //   if (percentage < 50) {
// //     console.log("Plz work hard");
// //   }
// // }

// // const percentage = 89;

// // if (percentage < 0 || percentage > 100) {
// //   console.log("Invalid Marks");
// // } else {
// //   if (percentage >= 90) {
// //     console.log("Grade A");
// //     if (percentage >= 95) {
// //       console.log("Reward = 100$");
// //     } else {
// //       console.log("Reward = 50$");
// //     }
// //   } else if (percentage >= 80) {
// //     console.log("Grade B");
// //   } else if (percentage >= 70) {
// //     console.log("Grade C");
// //   } else if (percentage >= 60) {
// //     console.log("Grade D");
// //   } else if (percentage >= 50) {
// //     console.log("Grade E");
// //   } else {
// //     console.log("Failed");
// //   }
// // }

// // number guessing game
// // radnom
// // prompt 0- 10

// // // calculator
// // prompt enter num1
// // prompt operation +  - * /
// // prompt enter num2

// // if(operation ==="+"){
// //   console.log(num1+num2)
// // }

// // Type Conversion
// // parseInt
// // parseFloat
// // Number
// // +
// // const num1 = parseInt(prompt("Enter num1"));
// // const operation = prompt("Enter operation  + - * /");
// // const num2 = parseFloat(prompt("Enter num2"));
// // const num1 = Number(prompt("Enter num1"));
// // const operation = prompt("Enter operation  + - * /");
// // const num2 = +prompt("Enter num2");
// // if (operation === "+") {
// //   console.log(num1 + num2);
// // } else if (operation === "-") {
// //   console.log(num1 - num2);
// // } else if (operation === "*") {
// //   console.log(num1 * num2);
// // } else if (operation === "/") {
// //   console.log(num1 / num2);
// // } else {
// //   console.log("Something went wrong");
// // }

// // if
// // else if
// // else

// // switch if
// // case else if
// // default else

// // switch(){
// //     case 1:
// //         console.log()

// //     default{

// //     }

// // }

// // const today = prompt("Enter day to check our menu☺️!").toLowerCase();

// // switch (today) {
// //   case "monday":
// //     console.log("Rice");
// //     break;

// //   case "tuesday":
// //     console.log("Chicken");
// //     break;

// //   case "wednesday":
// //     console.log("Daal");
// //     break;

// //   case "thursday":
// //     console.log("Meat");
// //     break;

// //   case "friday":
// //     console.log("Vegetables");
// //     break;

// //   case "saturday":
// //     console.log("Biryani");
// //     break;

// //   case "sunday":
// //     console.log("Resturant is closed");
// //     break;

// //   default:
// //     console.log("Please check spellings and try again");
// // }

// // Arrays And Array Methods
// // const name1 = "mughees";
// // const name2 = "john";
// // old array method
// // const student = new Array("john", "andrio", "brad", "adrian");
// // console.log(student);

// // const students = ["Ahmad", "Raza", "Saad", "Amir"];
// // CRUD
// // create  C
// // read  R
// // update U
// // delete  D
// // console.log(students);
// // console.log(students[1]); //access Read (R)
// // students[4] = "Zia";
// // students[students.length] = "Zia"; //Create (C)
// // console.log(students);
// // students[0] = "Ahmed"; //Update (U)
// // console.log(students);

// // delete students[2]; //Delete (D)
// // console.log(students);

// // Array Methods
// // PUSH POP
// // students.push("Haris", "Asad");
// // console.log(students);

// // students.pop();
// // console.log(students);

// // // SHIFT UNSHIFT

// // students.unshift("Jamal", "Abbas");
// // console.log(students);

// // students.shift();
// // console.log(students);
// // const username = prompt("Enter username");
// // const check = students.includes(username);
// // if (check) {
// //   console.log("username already exists");
// // } else {
// //   console.log("you are good to go");
// // }

// // Slice

// // const trimmedArr = students.slice(1, 3);
// // console.log(trimmedArr);
// // console.log(students);

// // Splice
// // const spliced = students.splice(2, 0, "Mughees");
// // console.log(spliced);
// // console.log(students);

// // const students = ["Ahmad", "Raza", "Saad", "Amir"];
// // const students2 = ["Ali", "Kabeer", "Asad", "Shehzad"];
// // Spread Operater  ...student
// // const totalStudents = [...students, ...students2];
// // console.log(totalStudents);
// // const sort = totalStudents.toSorted();
// // console.log(totalStudents);
// // console.log(sort);
// // const reverse = totalStudents.toReversed();
// // console.log(reverse);

// // TASK

// // if(
// // rock == scissor ||
// // paper == rock ||
// // scissor == paper || ){
// //     console.log("you losse")
// // }else{
// // console.log("You win")
// // }

// LOOPS
// console.log("heloo");

// FOR
// WHILE
// DO WHILE
// FOR IN ,array
// FOR OF ,objects

// FOR
// Starting point of loop
// Ending point of loop
// Increment
// Code

// for (let i = 1; i < 10; i++) {
//   console.log("Hello World!", i);
// }

// Tables
// for (let i = 1; i <= 200; i++) {
//   if (i >= 30) {
//     break;
//   }
//   console.log(2 * i);
// }

// const ages = [20, 21, 34, 56, 18, 17, 90];
// console.log(ages[0]);
// console.log(ages[1]);
// console.log(ages[2]);
// console.log(ages[3]);
// console.log(ages[4]);
// ages.push(101);
// ages.push(102);
// ages.push(103);
// ages.push(104);
// ages.push(105);
// console.log(ages);
// for (let i = 0; i < ages.length; i++) {
//   console.log(ages[i] + " Elder");
// }

// for (let age of ages) {
//   console.log(age);
// }

// let alive = true;
// let years = 0;
// while (alive) {
//   if (years >= 50) {
//     alive = false;
//     console.log("You died");
//     // break;
//   }
//   console.log("You are breathing");
//   years++;
// }

// ending point
//  true

// let userinput = "";

// while (userinput !== "exit") {
//   userinput = prompt("Enter something or enter 'exit' to break the loop");
// }
// let userinput = "";
// do {
//   userinput = prompt("Enter something or enter 'exit' to break the loop");
// } while (userinput == "exit");

// const number = Math.floor(Math.random() * 11);
// let chances = 5;
// console.log("Welcome to number guessing game :)");
// console.log("You have 5 chances to guess the correct number ");
// while (chances > 0) {
//   const userGuess = +prompt("Enter number between 0 - 10");
//   if (userGuess > 10 || userGuess < 0) {
//     console.log("Plz guess between  0 - 10");
//   } else {
//     if (userGuess === number) {
//       console.log("you won");
//       break;
//     } else if (userGuess > number) {
//       console.log("Guess Smaller");
//     } else if (userGuess < number) {
//       console.log("Guess Bigger");
//     } else {
//       console.log("Somehting went wrong");
//     }
//   }

//   chances--;
//   console.log("You have", chances, "chances left");
// }

// if (chances === 0) {
//   console.log("Game Over");
// }

// Array
// const students = ["hamzah", 25, "male", "peshawar", "abbas"];

// const cars = ["BMW", "Audi", "Ford", "Honda"];
// Object
// // const name = "john";
// const carInfo = {
//   // property
//   // key: value
//   // name: name,
//   name: "Civic",
//   model: 2022,
// };
// console.log(carInfo);
// console.table(carInfo);
// console.log(carInfo.name, carInfo.model);
// console.log(carInfo["name"], carInfo["model"]);

// const companyInfo = {
//   name: "ABC",
//   founded: 1998,
//   isRunning: true,
//   branches: ["us", "pak", "india"],
//   address: {
//     plot: 786,
//     street: "xyz",
//     city: "LA",
//     country: "US",
//   },
// };
// console.log(companyInfo.branches[0]);
// console.log(companyInfo.address.street);

// const myInfo = {
//   name: "John",
//   age: 29,
//   gender: "male",
//   martialStatus: "no",
// };
// console.log(myInfo.name);
// console.log(myInfo.age);
// console.log(myInfo.gender);
// console.log(myInfo.martialStatus);

// console.log(myInfo);
// Object.seal(myInfo);
// myInfo.martialStatus = "yes";
// myInfo.age = 40;
// myInfo.alive = "yes";
// console.log(myInfo);

// for (const key in myInfo) {
//   console.log(myInfo[key]);
// }

// const studentInfo = [
//   {
//     name: "john",
//     gender: "male",
//     age: 22,
//     class: "FSC",
//   },
//   {
//     name: "Rosess",
//     gender: "female",
//     age: 34,
//     class: "FA",
//   },
// ];
// console.log(studentInfo[0].class, studentInfo[0].name);

// const companyInfo = {
//   companyName: "TechVision Solutions",
//   founded: 2010,
//   headquarters: {
//     address: {
//       street: "123 Innovation Blvd",
//       city: "San Francisco",
//       state: "CA",
//       postalCode: "94103",
//       country: "USA",
//     },
//     phone: "+1 415-555-1234",
//     email: "info@techvisionsolutions.com",
//   },
//   employees: [
//     {
//       id: 101,
//       name: "Alice Johnson",
//       position: "CEO",
//       department: "Executive",
//       contact: {
//         email: "alice.j@techvisionsolutions.com",
//         phone: "+1 415-555-5678",
//       },
//       skills: ["Leadership", "Strategic Planning", "Public Speaking"],
//     },
//     {
//       id: 102,
//       name: "Robin Hood",
//       position: "CTO",
//       department: "Technology",
//       contact: {
//         email: "bob.s@techvisionsolutions.com",
//         phone: "+1 415-555-8765",
//       },
//       skills: ["Cloud Computing", "AI/ML", "DevOps"],
//     },
//   ],
//   departments: [
//     {
//       name: "Technology",
//       head: "Bob Smith",
//       teams: [
//         {
//           teamName: "AI Research",
//           members: ["Emily Carter", "John Lee"],
//           currentProjects: [
//             {
//               projectName: "Smart Assistant",
//               deadline: "2025-06-30",
//               status: "In Progress",
//             },
//             {
//               projectName: "Vision AI",
//               deadline: "2025-12-15",
//               status: "Planning",
//             },
//           ],
//         },
//         {
//           teamName: "Web Development",
//           members: ["Sarah Parker", "David Wilson"],
//           currentProjects: [
//             {
//               projectName: "E-commerce Platform",
//               deadline: "2025-03-31",
//               status: "Testing",
//             },
//           ],
//         },
//       ],
//     },
//     {
//       name: "Marketing",
//       head: "Karen Davis",
//       teams: [
//         {
//           teamName: "Social Media",
//           members: ["Nina Taylor", "Paul Adams"],
//           campaigns: ["Tech Expo 2025", "Summer Discounts"],
//         },
//       ],
//     },
//   ],
//   products: [
//     {
//       name: "Vision AI",
//       category: "Software",
//       price: 499.99,
//       features: [
//         "Object Detection",
//         "Facial Recognition",
//         "Real-Time Analysis",
//       ],
//     },
//     {
//       name: "Smart Assistant",
//       category: "Hardware",
//       price: 149.99,
//       features: ["Voice Control", "Smart Home Integration", "Custom Skills"],
//     },
//   ],
//   financials: {
//     revenue: 15000000,
//     expenses: 12000000,
//     profit: 3000000,
//     currency: "USD",
//   },
//   partners: [
//     { name: "CloudX", type: "Cloud Provider", since: 2018 },
//     { name: "InnovateHub", type: "R&D Partner", since: 2020 },
//   ],
//   certifications: ["ISO 9001", "ISO 27001", "GDPR Compliant"],
// };

/*

1 :Extract and print the following details:

The company name.
The year the company was founded.
The city where the company headquarters is located.
The phone number of the company.

output should be like

The company name is TechVision Solutions.
It was founded in 2010.
The headquarters is located in San Francisco.
The contact phone number is +1 415-555-1234.
*/

/*
2: Display a list of employee names and their positions in the following format:
output aisa ho 
Employees:
- Alice Johnson (CEO)
- Bob Smith (CTO)
- Sarah Parker (Developer)
*/

/*
3: Calculate and print the total number of products along with their names and prices in this format:
out put shoud be like
The company offers 2 products:
- Vision AI (Software): $499.99
- Smart Assistant (Hardware): $149.99
*/

// for (let i = 0; i < companyInfo.employees.length; i++) {
//   console.log(
//     companyInfo.employees[i].name,
//     "(" + companyInfo.employees[i].position + ")"
//   );
// }

// Functions?
// const num1 = 90;
// const num2 = 100;
// const result = num1 + num2;
// console.log(result);

// const num3 = 190;
// const num4 = 200;
// const result2 = num3 + num4;
// console.log(result2);

// Named Functions
// Arrow Functions
// Function Expression
// IIFE immediately invoked function expression
// Recursions?
// Clousers

// Named Functions
// Function Declration/Defination
// function Greet(username = "User") {
//   console.log("Welcome", username + "!");
// }
// Greet("John"); //calling/invoking function
// Greet("Andrio");
// Greet();
// Greet("Adrian");
// Arguments (args)  //send
// Parameters (params) //receive
// default params
// function Addition(a = 0, b = 0, c = 0) {
//   const result = a + b + c;
//   console.log(result);
// }
// Addition(30, 70, 90);
// Addition(33, 77, 23);
// Addition();

// ... rest
// function TradeMangement(...res) {
//   let result = 0;
//   for (let expense of res) {
//     result += expense;
//   }
//   return result;
// }
// let april = TradeMangement(10000, 23, 424, 6, 56, 457, 68, 68, 425, 29, 58);
// console.log(april);
// let may = TradeMangement(3000, 23, 424, 6, 56, 457);
// console.log(may);

// TradeMangement(10000, 23, 424, 6, 56, 457, 68, 68, 425, 29, 58);
// TradeMangement(10000, 23, 424, 6, 56, 457, 68, 68, 425, 29, 58);
// TradeMangement(20000, 23, 424, 6, 56, 457, 68, 68, 3, 5);
// TradeMangement(3000, 23, 424, 6, 56, 457);
// TradeMangement();

// let annualClosing = april + 4000;
// console.log(annualClosing);

// ARROW Functions?
// let Greet = (something = "user", ...res) => {
//   console.log("Welcome");
//   console.log("To corvit");
//   console.log(res);
//   return something;
// };
// console.log(Greet("sfsf", "fsfs", "fhgh"));
// console.log(Greet());

// let myName = "john"; //expression
// let Greet2 = function (a) {
//   console.log("i am function expression", a);
// };
// Greet2("fsf");
// Greet2("fhrh");
// Greet2("tjkyuk");
// Greet2("jtukyuk");

// IIFE
// var
// let
// const

// console.log(myName);
// var myName = "Andrio";

// console.log(age);
// let age = 34;

// global  scope
// let age = 89;
// block/local scope

// if (true) {
//   let fullname = "raza"; //block
//   console.log(age);
//   console.log(fullname);
// }
// console.log(fullname);

// for (let i = 0; i < 1; i++) {
//   console.log("loop", age);
// }

// function check() {
//   console.log("func", age);
// }
// check();

// if (true) {
//   var fullname = "John Doe";
//   console.log("inside", fullname);
// }
// console.log("outside", fullname);

// function check() {
//   var fullName = "andrio";
//   console.log(fullName);
// }
// check();
// console.log(fullName);
// function condition1() {
//   if (18 < 19) {
//     var fullName = "john doe";
//     console.log(fullName);
//   }
// }
// condition1();
// console.log(fullName);

// var private

// IIFE
// (function () {
//   if (true) {
//     var myName = "Khan";
//     console.log("How are you", myName);
//   }
// })();

// console.log(myName);

// let const

// Recursion?

// function recur() {
//   console.log("hello");
//   recur();
// }
// recur();

// Recursion
// const persons = []; //global
// let nums = 0;
// function FetchData() {
//   persons.push(nums);
//   nums++;
//   if (persons.length < 10) {
//     FetchData();
//   }
//   console.log(persons, nums);
// }
// FetchData();

// Loops (Arrays)

const fruits = [
  "Apple",
  "Banana",
  "Orange",
  "Mango",
  "Grapes",
  "Pineapple",
  "Strawberry",
  "Blueberry",
  "Watermelon",
  "Peach",
  "Cherry",
  "Pear",
  "Plum",
  "Kiwi",
  "Papaya",
  "Guava",
  "Lychee",
  "Fig",
  "Pomegranate",
  "Coconut",
  "Apricot",
  "Blackberry",
  "Raspberry",
  "Cranberry",
  "Dragonfruit",
  "Durian",
  "Jackfruit",
  "Passionfruit",
  "Tangerine",
  "Nectarine",
  "Cantaloupe",
  "Honeydew",
  "Mulberry",
  "Starfruit",
  "Gooseberry",
  "Persimmon",
  "Quince",
  "Tamarind",
  "Avocado",
  "Date",
  "Elderberry",
  "Boysenberry",
  "Currant",
  "Kumquat",
  "Salak",
  "Longan",
  "Rambutan",
  "Soursop",
  "Mangosteen",
  "Jujube",
];
// for (let i = 0; i < fruits.length; i++) {
//   console.log(fruits[i]);
// }

// forEach
// map
// filter
// reduce
// every
// some
// callBack
// item
// idx
// arr
// fruits.forEach((item, idx, arr) => {
//   // console.log(item, idx, arr);
//   if (idx % 2 == 0) {
//     console.log(item, "item aligns on even idx");
//   } else {
//     console.log(item, "item aligns on odd idx");
//   }
// });

// fruits.map((item, idx, arr) => {
//   console.log(item, idx, arr);
// });
// console.log(fruits);

// function forEach(cb) {
//   // console.log(cb);
//   cb();
// }
// One(() => {
//   console.log("I am callBack function");
// });

// const ages = [18, 17, 10, 10, 41, 33, 78, 56];

// const every = ages.every((item) => {
//   return item >= 9;
// });
// console.log(every);

// const some = ages.some((item) => {
//   return item >= 70;
// });
// console.log(some);

// const ages = [18, 17, 10, 10, 41, 33, 78, 56];
// const filteredAges = ages.filter((item) => {
//   return item >= 18;
// });
// console.log(filteredAges);

const employees = [
  {
    name: "Saad",
    age: 31,
    gender: "male",
    department: "Web",
  },
  {
    name: "Sammad",
    age: 20,
    gender: "male",
    department: "Graphic",
  },
  {
    name: "Alishba",
    age: 18,
    gender: "female",
    department: "Web",
  },
  {
    name: "Hania",
    age: 21,
    gender: "female",
    department: "AI",
  },
  {
    name: "Ahmad",
    age: 27,
    gender: "male",
    department: "AI",
  },
  {
    name: "Nimra",
    age: 24,
    gender: "female",
    department: "Marketing",
  },
  {
    name: "Hira",
    age: 22,
    gender: "female",
    department: "Marketing",
  },
  {
    name: "Saud",
    age: 29,
    gender: "male",
    department: "Web",
  },
];

const filteredEmployes = employees
  .filter((employee) => {
    return employee.gender == "male";
  })
  .map((item) => {
    const data = {
      name: item.name,
      department: item.department,
    };
    return data;
  });

console.log(filteredEmployes);

// const Data = filteredEmployes
// console.log(Data);
