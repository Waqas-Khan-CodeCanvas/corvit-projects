// console.log("first");
// setTimeout(() => {
//   console.log("second");
// }, 3000);
// console.log("third");
// console.log("forth");

// setInterval(() => {
//   console.log("interval");
// }, 3000);

// function fetchData(id, nextData) {
//   setTimeout(() => {
//     console.log("Data of id", id, "fetched :)");
//     nextData();
//   }, 3000);
// }

// callback
// fetchData(1, () => {
//   console.log("Fetching Data of id 1...");
//   fetchData(2, () => {
//     console.log("Fetching Data of id 2...");
//     fetchData(3, () => {
//       console.log("Fetching Data of id 4...");
//       fetchData(4, () => {
//         console.log("Fetching Data of id 5...");
//         fetchData(5);
//       });
//     });
//   });
// });

// fetchData(1); //3000
// fetchData(2); //3000
// fetchData(3); //3000
// fetchData(4); //3000

// let data = new Promise((resolve, reject) => {
//   setTimeout(() => {
//     resolve("data fetched");
//   }, 4000);
// });

// function Database(name) {
//   return new Promise((resolve, reject) => {
//     setTimeout(() => {
//       if (name) {
//         resolve({
//           username: name,
//           age: 32,
//           gender: "Male",
//         });
//       } else {
//         reject("something went wrong");
//       }
//     }, 3000);
//   });
// }
// Database("john")
//   .then((res) => {
//     return res;
//   })
//   .then((data) => {
//     const body = document.body;
//     const h2 = document.createElement("h2");
//     h2.innerText = data.username;
//     body.append(h2);
//   })
//   .catch((err) => {
//     console.log("error", err);
//   });

// async function FetchData() {
//   const h2 = document.createElement("h2");
//   try {
//     const res = await Database("John");
//     console.log(res);
//     h2.innerText = res.username;
//   } catch (err) {
//     h2.innerText = err;
//   } finally {
//     document.body.append(h2);
//   }
// }
// FetchData();
// const h1 = (document.createElement("h1").innerText = "by using dom");
// document.body.append(h1);

// try{

// } catch(err){

// } finally {

// }

const apiKey = "1b718757d4841ef88507cb2613bb6f34";
const apiUrl = `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}`;
const imageBase = "https://image.tmdb.org/t/p/w500";

const genreMap = {
  28: "Action",
  12: "Adventure",
  16: "Animation",
  35: "Comedy",
  80: "Crime",
  99: "Documentary",
  18: "Drama",
  10751: "Family",
  14: "Fantasy",
  36: "History",
  27: "Horror",
  10402: "Music",
  9648: "Mystery",
  10749: "Romance",
  878: "Sci-Fi",
  10770: "TV Movie",
  53: "Thriller",
  10752: "War",
  37: "Western",
};

// http verbs Get Post Delete Update/patch

async function FetchMovie() {
  try {
    const response = await fetch(apiUrl);
    const data = await response.json();
    const movies = data.results;
    movies.forEach((movie) => {
      const {
        title,
        overview,
        poster_path,
        release_date,
        vote_average,
        genre_ids,
      } = movie;

      const category = genre_ids.map((id) => genreMap[id]).join(", ");
      const img = document.createElement("img");
      img.src = imageBase + poster_path;

      document.body.append(img);
    });
  } catch (error) {
    console.log(error);
  }
}

FetchMovie();

// const myInfo = {
//   name: "john",
//   age: 22,
//   gender: "male",
// };
// const name = myInfo.name;
// const age = myInfo.age;
// const gender = myInfo.gender;
// console.log(name, age, gender);

// const { gender, name, age } = myInfo;
// console.log(age);
