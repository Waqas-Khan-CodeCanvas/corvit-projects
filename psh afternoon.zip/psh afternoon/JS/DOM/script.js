// document={
//     h1:"",
// }

// DOM
// Tree Like Structure

//      window //global
//     document
//       html
//     head     body
// title link

// document.getElementById;
// document.getElementsByTagName;
// document.getElementsByClassName;

// document.querySelector
// document.querySelectorAll

// window.document
// console.log(document.getElementById("heading"));
// document.getElementById("heading").style.color = "orange";
// background-color : ""
// backgroundColor
// const h1 = document.getElementById("heading");
// console.log(h1);
// // h1.innerText = "Changed";
// h1.textContent = "Text Content";

// console.log("inner", h1.innerText);
// console.log(h1.textContent);
// console.log(h1.outerHTML);

// const paras = document.getElementsByTagName("p");
// console.log(paras);
// paras[0].style.backgroundColor = "orange";
// paras[0].innerText = "changed by using dom";
// for (let para of paras) {
//   para.style.backgroundColor = "black";
//   para.style.color = "white";
// }

// const list = document.getElementsByClassName("item");
// console.log(list);

// list[2].style.color = "red";

// for (const item of list) {
//   item.style.color = "red";
//   item.style.fontSize = "38px";
// }

// const tagName = document.querySelector("h1");
// tagName.style.color = "red";
// console.log(tagName);

// const byId = document.querySelector("#para1");
// byId.textContent = "Changed by using DOM";

// const byClass = document.querySelector(".item");
// byClass.style.backgroundColor = "orange";

// const byAttribute = document.querySelector("input[type=email]");
// byAttribute.style.backgroundColor = "plum";

// nth-child()
// nth-of-type
// const psuedo = document.querySelector("li:nth-of-type(even)");
// psuedo.style.backgroundColor = "purple";

// const listItems = document.querySelectorAll("li:nth-of-type(even)");
// console.log(listItems);

// const listItems = document.querySelectorAll("li:nth-of-type(even)");
// for (let item of listItems) {
//   item.style.color = "red";
// }

// const h1 = document.querySelector("h1");
// const input = document.createElement("input");

// Attributes
// getAttribute
// setAttribute
// h1.setAttribute("id", "heading2");
// h1.setAttribute("class", "from-js");
// h1.classList.add("from-js");
// input.setAttribute("type", "text");
// input.setAttribute("placeholder", "plz enter your name");
// input.setAttribute("maxLength", "10");
// input.classList.add("class1");
// input.classList.remove("class1");
// console.log(input.classList);
// console.log(h1.getAttribute("class"));
// h1.setAttribute("id", "heading-from-js");
// const list = document.querySelector("ol");
// const li = document.createElement("li");

// li.innerText = "Apple";

// list.prepend(li);
// list.append(li);
// list.after(li);
// list.before(li);
// console.log(input);
// h1.prepend(input);
// h1.append(input);
// h1.after(input);
// h1.before(input);

// prepend;
// append;
// after;
// before;

// Events & Event Handling
// const btn = document.querySelector("button");
// const input = document.querySelector("input");

// btn.addEventListener("click", () => {
//   // alert("you clicked me!");
//   console.log("Clicked!");
// });

// btn.addEventListener("contextmenu", () => {
//   console.log("right clicked");
// });

// // mouseover
// // mouseout

// // mouseenter
// // mouseleave
// btn.addEventListener("mouseover", () => {
//   console.log("mouse over");
//   btn.style.scale = "1.1";
// });
// btn.addEventListener("mouseout", () => {
//   console.log("mouse out");
//   btn.style.scale = "1";
// });

// focusin
// focusout

// focus
// blur

// input.addEventListener("focusin", () => {
//   input.style.width = "200px";
//   // input.style.scale = "1.1";
// });

// input.addEventListener("focusout", () => {
//   input.style.width = "30px";
//   // input.style.scale = "1";
// });

// function HandleDoubleClick() {
//   if (document.body.style.backgroundColor === "black") {
//     document.body.style.backgroundColor = "white";
//     document.body.style.color = "black";
//   } else {
//     document.body.style.backgroundColor = "black";
//     document.body.style.color = "white";
//   }
// }

// btn.addEventListener("click", HandleDoubleClick);

// const images = document.querySelectorAll("img");
// console.log(images);

// for (let image of images) {
//   image.addEventListener("mouseover", () => {
//     image.style.scale = "1.1";
//     image.style.opacity = "1";
//     image.style.width = "300px";
//   });
//   image.addEventListener("mouseout", () => {
//     image.style.scale = "1";
//     image.style.opacity = "0.6";
//     image.style.width = "200px";
//   });
// }

// const input = document.querySelector("input");

// // event object
// input.addEventListener("keydown", (evt) => {
//   console.log(evt.key);
//   // console.log("key down");
// });
// input.addEventListener("keypress", () => {
//   console.log("key pressed");
// });

// input.addEventListener("keyup", () => {
//   console.log("Key up");
// });
// input.addEventListener("change", (e) => {
//   console.log(e);
//   console.log(e.target);
//   console.log(e.target.value);
//   console.log("Changed");
// });

// const form = document.querySelector("form");
// const dbname = "mughees_javed";
// const dbpass = "112233";
// function HandleSubmit(e) {
//   e.preventDefault();
//   const name = e.target[0].value;
//   const pass = e.target[1].value;
//   console.log({
//     username: name,
//     password: pass,
//   });
//   e.target.reset();
// }

// form.addEventListener("submit", (e) => HandleSubmit(e));

// document.body.addEventListener("contextmenu", (event) => {
//   event.preventDefault();
// });

const form = document.querySelector("form");

function HandleSubmit(e) {
  e.preventDefault();
  const fullname = e.target.fullname.value;
  const email = e.target.email.value;
  const password = e.target.password.value;
  const gender = e.target.gender.value;
  const courses = e.target.course;
  const selectedCourses = [];
  for (let course of courses) {
    if (course.checked) {
      selectedCourses.push(course.value);
    }
  }
  const province = e.target.province.value;
  const dob = e.target.dob.value;
  const data = {
    name: fullname,
    email: email,
    pass: password,
    gender: gender,
    course: selectedCourses,
    province: province,
    dateOfBirth: dob,
  };

  console.log(data);
  e.target.reset();
}

form.addEventListener("submit", (evt) => {
  HandleSubmit(evt);
});
