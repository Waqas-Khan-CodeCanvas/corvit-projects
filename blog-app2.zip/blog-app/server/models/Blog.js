import mongoose from "mongoose";

const BlogSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Title is required!"],
    },
    description: {
      type: String,
      required: [true, "Description is required!"],
    },
    imageUrl: {
      type: String,
      required: [true, "Image is required!"],
    },
    read_time: {
      type: Number,
      required: [true, "Read Time is required"],
    },
    author: {
      type: String,
      required: [true, "Author is required!"],
    },
  },
  {
    timestamps: true,
  }
);

const Blog = mongoose.model("blogs", BlogSchema);
export default Blog;
