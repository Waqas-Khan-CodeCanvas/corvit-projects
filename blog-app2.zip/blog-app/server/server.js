import mongoose from "mongoose";
import express from "express";
import Blog from "./models/Blog.js";
import cors from "cors";

const App = express();

App.use(cors());
App.use(express.json());

mongoose
  .connect("mongodb://localhost:27017/blog-app")
  .then(() => {
    console.log("Database conncted");
  })
  .catch((err) => {
    console.log(err.message);
  });

App.get("/", (req, res) => {
  res.send("Welcome to home");
});

App.post("/new-blog", async (req, res) => {
  try {
    const blog = req.body.formData;
    const newBlog = await Blog.create(blog);
    res.send("Post created");
  } catch (err) {
    console.log(err);
  }
});

const port = 3000;
App.listen(port, () => {
  console.log(`App is running on http://localhost:${port}`);
});
