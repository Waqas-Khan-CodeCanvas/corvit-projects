import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div className="flex justify-between items-center bg-amber-700 text-white p-5 text-xl font-semibold ">
      <Link to="/">
        <h1 className="font-bold text-4xl">Peshawar Blogs</h1>
      </Link>
      <ul className="flex gap-6">
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/add-post">Add Post</Link>
        </li>
      </ul>
      <ul className="flex gap-1">
        <li>
          <Link to="/login">Login</Link>
        </li>
        /
        <li>
          <Link to="/register">Register</Link>
        </li>
      </ul>
    </div>
  );
}

export default Navbar;
