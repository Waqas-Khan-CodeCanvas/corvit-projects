import { Link } from "react-router-dom";
import { DUMMY_DATA } from "../data.js";
function Home() {
  return (
    <div className="flex justify-center   flex-wrap gap-x-5 gap-y-3 m-0 p-7">
      {DUMMY_DATA.map((blog) => (
        <Link
          to={`/blog/${blog.id}`}
          key={blog.id}
          className="h-[350px] w-96 bg-slate-200 rounded-4xl posts"
        >
          <img
            src={blog.image_url}
            alt={blog.title}
            className="rounded-t-4xl"
          />
          <div className=" p-3 font-bold ">
            <h2 className=" text-3xl">{blog.title}</h2>
            <h2 className="text-xl font-semibold">
              Author : <span className="text-red-600">{blog.author}</span>
            </h2>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default Home;
