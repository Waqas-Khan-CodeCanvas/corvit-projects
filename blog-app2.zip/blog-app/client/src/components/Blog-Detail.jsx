import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { DUMMY_DATA } from "../data";

function BlogDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const blog = DUMMY_DATA.find((data) => data.id === +id);

  if (!blog) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-700 text-xl">
        Blog not found!
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <button
          onClick={() => navigate(-1)}
          className="text-sm bg-orange-600 text-white px-4 py-2 rounded-xl hover:bg-orange-700 transition"
        >
          &lt; Back
        </button>

        {/* Blog Card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <img
            src={blog.image_url}
            alt={blog.title}
            className="w-full h-72 object-cover"
          />

          <div className="p-8 space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">{blog.title}</h1>

            <div className="flex items-center justify-between text-sm text-gray-500">
              <p>
                By{" "}
                <span className="font-medium text-gray-700">{blog.author}</span>
              </p>
              <p>
                {blog.published_date} • {blog.read_time}
              </p>
            </div>

            <p className="text-gray-700 leading-relaxed">{blog.desription}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BlogDetail;
