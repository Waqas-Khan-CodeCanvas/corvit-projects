export const DUMMY_DATA = [
  {
    id: 1,
    title: "First Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 2,
    title: "Second Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 3,
    title: "Third Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 4,
    title: "Forth Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 5,
    title: "Fifth Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 6,
    title: "Sixth Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 7,
    title: "Seventh Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
  {
    id: 8,
    title: "Eight Blog",
    desription:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus non asperiores aliquid id officiis eaque nostrum, voluptatem dolor? Perferendis ipsa laborum numquam iusto, similique suscipit amet aliquid minima necessitatibus quam ratione officia rerum, aperiam soluta?",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John Doe",
    read_time: "7 mints",
    published_date: "26-05-2025",
  },
];
