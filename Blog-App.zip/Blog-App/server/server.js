import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import Blog from "./models/Blog.js";

const App = express();
// middlewears
App.use(cors());
App.use(express.json());
mongoose
  .connect("mongodb://localhost:27017/evening-blog-app")
  .then(() => {
    console.log("Database connected");
  })
  .catch((err) => {
    console.log(err);
  });

App.get("/blogs", async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.send(blogs);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

App.post("/new-blog", async (req, res) => {
  //   const newBlog = await Blog.create({
  //     title: req.body.title,
  //     description: req.body.description,
  //     imageUrl: req.body.imageUrl,
  //     author: req.body.author,
  //     readTime: req.body.readTime,
  //   });
  try {
    const newBlog = await Blog.create(req.body);
    res.send("Data saved");
  } catch (err) {
    res.status(500).send(err.message);
  }
});

const port = 3000;
App.listen(port, () => {
  console.log(`App is running on http://localhost:${port}`);
});
