import mongoose from "mongoose";

const BlogSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Title is required!"],
    },
    description: {
      type: String,
      required: [true, "Description is required!"],
    },
    imageUrl: {
      type: String,
      required: [true, "Image is required!"],
    },
    author: {
      type: String,
      required: [true, "Author is required!"],
    },
    readTime: {
      type: Number,
      required: [true, "Read Time is reuired!"],
    },
  },
  {
    timestamps: true,
  }
);

const Blog = mongoose.model("blog", BlogSchema);
export default Blog;
