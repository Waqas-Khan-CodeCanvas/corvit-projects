import { Link } from "react-router-dom";

import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";

function Home() {
  const [Blogs, setBlogs] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:3000/blogs")
      .then((res) => {
        setBlogs(res.data);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, []);
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-5">
      <h1 className="text-4xl font-extrabold text-center text-gray-800 mb-10">
        Latest Blogs
      </h1>
      <div className="flex flex-wrap justify-center gap-8">
        {Blogs.length > 0 ? (
          Blogs.map((blog) => (
            <Link to={`/blog/${blog.id}`} key={blog._id}>
              <div className="bg-white w-[300px] rounded-2xl shadow-md blog">
                <img
                  src={blog.imageUrl}
                  alt={blog.title}
                  className="h-[170px] w-full object-cover rounded-t-2xl"
                />
                <div className="p-4">
                  <h2 className="font-bold text-lg text-gray-800 mb-2 truncate">
                    {blog.title}
                  </h2>
                  <div className="flex justify-between">
                    <p className="text-sm text-gray-500">
                      By{" "}
                      <span className="font-semibold text-gray-700">
                        {blog.author}
                      </span>
                    </p>
                    <p className="text-sm text-gray-500">
                      {blog.read_time} min read
                    </p>
                  </div>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div>No blogs Found</div>
        )}
      </div>
    </div>
  );
}

export default Home;
