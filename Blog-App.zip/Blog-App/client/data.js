export const BLOGS_DATA = [
  {
    id: 1,
    title: "First Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "John1",
    read_time: 10,
  },
  {
    id: 2,
    title: "second Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Anna",
    read_time: 7,
  },
  {
    id: 3,
    title: "Third Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Sara",
    read_time: 11,
  },
  {
    id: 4,
    title: "Forth Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Andrio",
    read_time: 10,
  },
  {
    id: 5,
    title: "Fifth Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Alison",
    read_time: 7,
  },
  {
    id: 6,
    title: "Sixth Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Brad",
    read_time: 9,
  },
  {
    id: 7,
    title: "Seventh Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Jiya",
    read_time: 5,
  },
  {
    id: 8,
    title: "Eigth Blog",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus tempora enim voluptate. Itaque nesciunt pariatur eaque repellendus, necessitatibus doloribus quidem voluptates rem laudantium dignissimos reiciendis, voluptatibus magnam natus et praesentium!",
    image_url:
      "https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D",
    author: "Elon Musk",
    read_time: 15,
  },
];
