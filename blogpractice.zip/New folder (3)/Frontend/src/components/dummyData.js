const dummyData = [
  {
    id: 1,
    title: "first",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNAkB1j2W0ejEMyWFYmTpvMoKYCzy99XwD_Q&s",
    description:
      "Add a short but compelling description of your blog post. This should summarize the main idea or highlight what readers can expect. Keep it concise—around 1–2 sentences—to catch attention and give context.",
    author: "john Doe",
    readTime: 10,
  },
  {
    id: 2,
    title: "second",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNAkB1j2W0ejEMyWFYmTpvMoKYCzy99XwD_Q&s",
    description:
      "Add a short but compelling description of your blog post. This should summarize the main idea or highlight what readers can expect. Keep it concise—around 1–2 sentences—to catch attention and give context.",
    author: "john Doe",
    readTime: 10,
  },
  {
    id: 3,
    title: "third",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNAkB1j2W0ejEMyWFYmTpvMoKYCzy99XwD_Q&s",
    description:
      "Add a short but compelling description of your blog post. This should summarize the main idea or highlight what readers can expect. Keep it concise—around 1–2 sentences—to catch attention and give context.",
    author: "john Doe",
    readTime: 10,
  },
];

export default dummyData;
