import React, { useState } from "react";
import { Menu, X } from "lucide-react";
import { Link } from "react-router-dom";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Brand Name */}
          <div className="text-2xl font-bold text-blue-600">MyBlog</div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-6">
            <Link
              to="/"
              className="text-gray-700 hover:text-blue-600 font-medium"
            >
              Home
            </Link>
            <Link
              to="/AddBlog"
              className="text-gray-700 hover:text-blue-600 font-medium"
            >
              Add Blog
            </Link>
            <Link
              to="/Register"
              className="text-gray-700 hover:text-blue-600 font-medium"
            >
              Register
            </Link>
            <Link
              to="/Login"
              className="text-gray-700 hover:text-blue-600 font-medium"
            >
              Login
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-gray-700 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {isOpen && (
        <div className="md:hidden px-4 pb-4 space-y-2">
          <Link to="/" className="block text-gray-700 hover:text-blue-600">
            Home
          </Link>
          <Link to="/AddPost" className="block text-gray-700 hover:text-blue-600">
            Add Blog
          </Link>
          <Link to="/Register" className="block text-gray-700 hover:text-blue-600">
            Register
          </Link>
          <Link to="/Login" className="block text-gray-700 hover:text-blue-600">
            Login
          </Link>
        </div>
      )}
    </nav>
  );
}

export default Navbar;
