import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function Update() {
  const { id } = useParams();
  //   console.log(id);
  const [blogs, setblogs] = useState({});
  
  function handlerUpdate(e) {
      e.preventDefault();
      const dataupdate = {
      title: e.target.title.value,
      description: e.target.description.value,
      imageUrl: e.target.image.value,
      author: e.target.author.value,
      readTime: e.target.readTime.value,
    };

    // console.log(dataupdate)
    
    axios
    .patch(`http://localhost:3000/blog/${id}/update`,  {dataupdate} )
      .then((res) =>{
          console.log("data updated", res.data);
        })
        .catch((e) => console.log(e.message));
    }
    
    useEffect(() => {
      axios
        .get(`http://localhost:3000/blog/${id}`)
        .then((res) => {
         
          setblogs(res.data);
        })
  
        .catch((err) => console.log(err.message));
    }, [id]);
    return (
        <div>
      <form
        onSubmit={(e) => handlerUpdate(e)}
        className="max-w-lg mx-auto bg-white p-6 rounded-md shadow-md space-y-5 mt-8"
      >
        <h2 className="text-2xl font-semibold mb-4 text-blue-800">
          Edit : {blogs.title}
        </h2>

        <div>
          <label
            htmlFor="title"
            className="block mb-1 font-medium text-gray-700"
          >
            Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            defaultValue={blogs.title}
            required
            placeholder="Enter blog title"
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label
            htmlFor="description"
            className="block mb-1 font-medium text-gray-700"
          >
            Description
          </label>
          <textarea
            type="text"
            id="description"
            name="description"
            defaultValue={blogs.description}
            required
            placeholder="Describe the blog image"
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label
            htmlFor="author"
            className="block mb-1 font-medium text-gray-700"
          >
            Author Name
          </label>
          <input
            type="text"
            id="author"
            name="author"
            defaultValue={blogs.author}
            required
            placeholder="Author's name"
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label
            htmlFor="readTime"
            className="block mb-1 font-medium text-gray-700"
          >
            Read Time (minutes)
          </label>
          <input
            type="number"
            id="readTime"
            name="readTime"
            defaultValue={blogs.readTime}
            min="1"
            required
            placeholder="e.g. 5"
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="url" className="block mb-1 font-medium text-gray-700">
            Blog URL
          </label>
          <input
            type="url"
            id="url"
            name="image"
            defaultValue={blogs.imageUrl}
            required
            placeholder="https://example.com/your-blog-post"
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700 transition"
        >
          Edit
        </button>
      </form>
    </div>
  );
}

export default Update;
