import React from "react";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddBlog() {

  const navigate = useNavigate();
  const [Blogs, setBlogs] = useState({
    title: "",
    description: "",
    imageUrl: "",
    author: "",
    readTime: 0,
  });

 

  function handlerSubmit(e) {
    try {
      e.preventDefault();
      setBlogs(() => {
        Blogs.title = e.target.title.value;
        Blogs.description = e.target.description.value;
        Blogs.imageUrl = e.target.image.value;
        Blogs.author = e.target.author.value;
        Blogs.readTime = e.target.readTime.value;
      });
      axios
        .post("http://localhost:3000/blogpost", { Blogs })
        .then((res) => console.log("Data Send Succefully", res.data))
        .catch((e) => console.log(e.message));
      // console.log(Blogs);
    } catch (err) {
      console.log(err.message);
    }finally{
      e.target.reset()
    }
  }

  return (
    <form
      onSubmit={(e) => handlerSubmit(e)}
      className="max-w-lg mx-auto bg-white p-6 rounded-md shadow-md space-y-5 mt-8"
    >
      <h2 className="text-2xl font-semibold mb-4 text-gray-800">
        Add Blog Information
      </h2>

      <div>
        <label htmlFor="title" className="block mb-1 font-medium text-gray-700">
          Title
        </label>
        <input
          type="text"
          id="title"
          name="title"
          required
          placeholder="Enter blog title"
          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label
          htmlFor="description"
          className="block mb-1 font-medium text-gray-700"
        >
          Description
        </label>
        <textarea
          type="text"
          id="description"
          name="description"
          required
          placeholder="Describe the blog image"
          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label
          htmlFor="author"
          className="block mb-1 font-medium text-gray-700"
        >
          Author Name
        </label>
        <input
          type="text"
          id="author"
          name="author"
          required
          placeholder="Author's name"
          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label
          htmlFor="readTime"
          className="block mb-1 font-medium text-gray-700"
        >
          Read Time (minutes)
        </label>
        <input
          type="number"
          id="readTime"
          name="readTime"
          min="1"
          required
          placeholder="e.g. 5"
          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label htmlFor="url" className="block mb-1 font-medium text-gray-700">
          Blog URL
        </label>
        <input
          type="url"
          id="url"
          name="image"
          required
          placeholder="https://example.com/your-blog-post"
          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <button  onClick={() => {
        navigate(-1);
      }
      }
        type="submit"
        className="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700 transition"
      >
        Submit Blog
      </button>
    </form>
  );
}

export default AddBlog;
