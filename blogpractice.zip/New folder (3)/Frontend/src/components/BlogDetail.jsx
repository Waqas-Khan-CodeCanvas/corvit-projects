import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

function BlogDetail() {
  const { id } = useParams();
  const [blogs, setblogs] = useState({});

  useEffect(() => {
    try {
      axios
        .get(`http://localhost:3000/blog/${id}`)
        .then((res) => setblogs(res.data))
        .catch((err) => console.log(err.message));
    } catch (err) {
      console.log(err.message);
    }
  }, [id]);

  if (!blogs || Object.keys(blogs).length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center text-xl text-red-600 font-semibold">
        Blogs not found
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg mt-10 space-y-6">
      <img
        src={blogs.imageUrl}
        alt={blogs.title}
        className="w-full h-64 object-cover rounded-lg"
      />

      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-800">
          Title: <span className="text-blue-700">{blogs.title}</span>
        </h2>
        <h2 className="text-xl font-semibold text-gray-800">
          Read Time: <span className="text-blue-700">{blogs.readTime}</span>
        </h2>
      </div>

      <h2 className="text-lg text-gray-800">
        Author Name:{" "}
        <span className="text-blue-700 font-medium">{blogs.author}</span>
      </h2>

      <h2 className="text-lg text-gray-800">
        Description:{" "}
        <span className="text-blue-700 font-medium">{blogs.description}</span>
      </h2>

      <h2 className="text-sm text-gray-600">
        Created At: <span className="text-blue-700">{blogs.createdAt}</span>
      </h2>

      <h2 className="text-sm text-gray-600">
        Updated At: <span className="text-blue-700">{blogs.updatedAt}</span>
      </h2>

      <div className="flex justify-between  mt-6">
        <Link to={`/blog/${blogs._id}/update`}>
          <button className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition">
            Edit
          </button>
        </Link>
        <Link to={`/blog/${blogs._id}/update`}>
          <button className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition">
            Delete
          </button>
        </Link>
      </div>
    </div>
  );
}

export default BlogDetail;
