import React from "react";

function Footer() {
  return (
    <footer className="bg-white text-gray-800 py-6 mt-10 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          {/* Left Section */}
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <h2 className="text-lg font-bold text-blue-700 ">MyBlog</h2>
            <p className="text-sm">
              © {new Date().getFullYear()} MyBlog. All rights reserved.
            </p>
          </div>

          {/* Center Links */}
          <div className="flex space-x-6 mb-4 md:mb-0">
            <a href="#" className="hover:text-blue-600 text-sm">
              Home
            </a>
            <a href="#" className="hover:text-blue-600 text-sm">
              Add Blog
            </a>
            <a href="#" className="hover:text-blue-600 text-sm">
              Register
            </a>
            <a href="#" className="hover:text-blue-600 text-sm">
              Login
            </a>
          </div>

          {/* Right Section */}
          <div className="text-sm text-center md:text-right">
            <p>Made with ❤️ by Moosa</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
