import React from "react";
import Home from "./components/Home";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AddBlog from "./components/AddBlog";
import BlogDetail from "./components/BlogDetail";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/login";
import Register from "./components/Register";
import Update from "./components/update";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/AddBlog" element={<AddBlog />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Register" element={<Register />} />
          <Route path="/blog/:id" element={<BlogDetail />} />
          <Route path="/blog/:id/update" element={<Update />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
