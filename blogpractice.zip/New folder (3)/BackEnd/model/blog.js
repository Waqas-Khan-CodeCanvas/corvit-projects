import mongoose from "mongoose";

const blogScheema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Title is required"],
  },
  author: {
    type: String,
    required: [true, "author is required"],
  },
  description: {
    type: String,
    required: [true, "Description is required"],
  },
  imageUrl: {
    type: String,
    required: [true, "Image is required"],
  },
  readTime : {
    type : Number,
    required : [true , "Read time is required"]
  }
},{
    timestamps : true
});


const blog = mongoose.model("blog" , blogScheema)
export default blog
