import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import blog from "./model/blog.js";

mongoose
  .connect("mongodb://localhost:27017/blogpost")
  .then(() => {
    console.log("Data base is connected Successfully ");
  })
  .catch((e) => {
    console.log(e.message);
  });

const App = express();
App.use(express.json());
App.use(cors());

App.get("/", (req, res) => {
  console.log("hello");
  res.send("hello");
});


// get   
App.get("/blogs", async (req, res) => {
  const allData = await blog.find();
  res.send(allData);
});

// update 
App.patch("/blog/:id/update", async (req, res) => {
  const id = req.params.id;
  const data = req.body.dataupdate;
  const response = await blog.findByIdAndUpdate(id, data);
  console.log(response);
  res.send(response);
});

App.get("/blog/:id", async (req, res) => {
  const blogid = req.params.id;
  const data = await blog.findById(blogid);
  res.send(data);
});

App.post("/blogpost", async (req, res) => {
  // console.log(req.body.Blogs);
  const data = req.body.Blogs;
  const blogs = await blog.create(data);
  console.log(blogs);
  res.send(blogs);
});
const port = 3000;

App.listen(port, () => {
  console.log(`http://localhost:${port}`);
});
